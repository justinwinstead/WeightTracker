package com.jwinstead.weighttracker;

public class Weight {
    private long mId;
    private long mDate;
    private long mWeight;
    private String mUser;

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getDate() {
        return mDate;
    }

    public void setDate(long date) {
        mDate = date;
    }

    public long getWeight() {
        return mWeight;
    }

    public void setWeight(long weight) {
        mWeight = weight;
    }

    public String getUser() {
        return mUser;
    }

    public void setUser(String user) {
        mUser = user;
    }
}
