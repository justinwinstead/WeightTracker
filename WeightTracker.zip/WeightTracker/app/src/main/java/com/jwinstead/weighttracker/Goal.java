package com.jwinstead.weighttracker;

public class Goal {
    private long mId;
    private long mGoal;
    private String mUser;

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getGoal() {
        return mGoal;
    }

    public void setGoal(long goal) {
        mGoal = goal;
    }

    public String getUser() {
        return mUser;
    }

    public void setUser(String user) {
        mUser = user;
    }
}
