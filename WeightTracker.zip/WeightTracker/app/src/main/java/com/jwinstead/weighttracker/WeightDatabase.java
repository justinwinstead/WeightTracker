package com.jwinstead.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


public class WeightDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "weight.db";

    private static WeightDatabase mWeightDb;

    // singleton method to ensure only one instance of the database exists
    public static WeightDatabase getInstance(Context context){
        if (mWeightDb == null) {
            mWeightDb = new WeightDatabase(context);
        }
        return mWeightDb;
    }

    // private constructor to assist singleton
    private WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // class containing table and column names for user table
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    // class containing table and column names for goal table
    private static final class GoalTable {
        private static final String TABLE = "goals";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL = "goal";
        private static final String COL_USER = "user";
    }

    // class containing table and column names for weight table
    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_DATE = "date";
        private static final String COL_USER = "user";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create users table
        db.execSQL("create table " + UserTable.TABLE + " (" +
                        UserTable.COL_USERNAME + " primary key, " +
                        UserTable.COL_PASSWORD + ")"
        );

        // create goals table
        db.execSQL("create table " + GoalTable.TABLE + " (" +
                GoalTable.COL_ID + " integer primary key autoincrement, " +
                GoalTable.COL_GOAL + " int, " +
                GoalTable.COL_USER + " not null, " +
                "foreign key(" + GoalTable.COL_USER + ") references " +
                UserTable.TABLE + "(" + UserTable.COL_USERNAME + ") on delete cascade)"
        );

        // create weights table
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer primary key autoincrement, " +
                WeightTable.COL_WEIGHT + " int, " +
                WeightTable.COL_DATE + " int, " +
                WeightTable.COL_USER + " not null, " +
                "foreign key(" + WeightTable.COL_USER + ") references " +
                UserTable.TABLE + " (" + UserTable.COL_USERNAME + ") on delete cascade)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + GoalTable.TABLE);
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // if db is open enable foreign keys
        if (!db.isReadOnly()) {
            db.setForeignKeyConstraintsEnabled(true);
        }
    }

    // method to obtain all weights in system for a given user
    public List<Weight> getWeights(String username) {
        List<Weight> weights = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_USER + " = ? order by " + WeightTable.COL_DATE + " desc";

        // use sql string to move through all weights for the user
        Cursor cursor = db.rawQuery(sql, new String[]{ username });
        if (cursor.moveToFirst()) {
            do {
                Weight weight = new Weight();
                weight.setId(cursor.getLong(0));
                weight.setWeight(cursor.getLong(1));
                weight.setDate(cursor.getLong(2));
                weight.setUser(cursor.getString(3));
                weights.add(weight);
            } while (cursor.moveToNext());
        }

        // close cursor
        cursor.close();

        return weights;
    }

    // method to obtain a weight
    public Weight getWeight(long weightId) {
        Weight weight = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + WeightTable.TABLE + " where " +
                WeightTable.COL_ID + " = ?";

        // use sql string to get the weight with the provided id
        Cursor cursor = db.rawQuery(sql, new String[] { Float.toString(weightId) });
        if (cursor.moveToFirst()) {
            weight = new Weight();
            weight.setId(cursor.getLong(0));
            weight.setWeight(cursor.getLong(1));
            weight.setDate(cursor.getLong(2));
            weight.setUser(cursor.getString(3));
        }

        // close cursor
        cursor.close();

        return weight;
    }

    // method to add weight to database
    public void addWeight(Weight weight) {
        SQLiteDatabase db = getWritableDatabase();

        // add values to a ContentValues object
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight.getWeight());
        values.put(WeightTable.COL_DATE, weight.getDate());
        values.put(WeightTable.COL_USER, weight.getUser());

        // insert values into database and assign id to the weight object
        long weightId = db.insert(WeightTable.TABLE, null, values);
        weight.setId(weightId);
    }

    // method to update a given weight in the system
    public void updateWeight(Weight weight) {
        SQLiteDatabase db = getWritableDatabase();

        // add values to a ContentValues object
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_ID, weight.getId());
        values.put(WeightTable.COL_WEIGHT, weight.getWeight());
        values.put(WeightTable.COL_DATE, weight.getDate());
        values.put(WeightTable.COL_USER, weight.getUser());

        // update weight in the database
        db.update(WeightTable.TABLE, values, WeightTable.COL_ID
                + " = '" + weight.getId() + "'", null);
    }

    // method to delete a weight from the database
    public void deleteWeight(long weightId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(WeightTable.TABLE,
                WeightTable.COL_ID + " = " + weightId, null);
    }

    // method to obtain a goal
    public Goal getGoal(String username) {
        Goal goal = null;

        SQLiteDatabase db = this.getReadableDatabase();

        // use sql string to get the goal with the provided id
        String sql = "select * from " + GoalTable.TABLE + " where " +
                GoalTable.COL_USER + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        if (cursor.moveToFirst()) {
            goal = new Goal();
            goal.setId(cursor.getInt(0));
            goal.setGoal(cursor.getInt(1));
            goal.setUser(cursor.getString(2));
        }

        // close cursor
        cursor.close();

        return goal;
    }

    // method to add goal to database
    public void addGoal(Goal goal) {
        SQLiteDatabase db = getWritableDatabase();

        // add values to a ContentValues object
        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_GOAL, goal.getGoal());
        values.put(GoalTable.COL_USER, goal.getUser());

        // insert values into database and assign id to the goal object
        long goalId = db.insert(GoalTable.TABLE, null, values);
        goal.setId(goalId);
    }

    // method to update a given goal in the system
    public void updateGoal(Goal goal) {
        SQLiteDatabase db = getWritableDatabase();

        // add values to a ContentValues object
        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_ID, goal.getId());
        values.put(GoalTable.COL_GOAL, goal.getGoal());
        values.put(GoalTable.COL_USER, goal.getUser());

        // update goal in the database
        db.update(GoalTable.TABLE,
                values, GoalTable.COL_ID + " = '" + goal.getId() + "'", null);
    }

    // method to delete goal from the database, if needed
    public void deleteGoal(long goalId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(GoalTable.TABLE,
                GoalTable.COL_ID + " = " + goalId, null);
    }

    // method to obtain a user
    public User getUser(String username) {
        User user = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + UserTable.TABLE + " where username = ?";

        // use sql string to get the user with the provided username
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        if (cursor.moveToFirst()) {
            user = new User();
            user.setUsername(cursor.getString(0));
            user.setPassword(cursor.getString(1));
        }

        // close cursor
        cursor.close();

        return user;
    }

    // method to add user to database
    public void addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();

        // add values to a ContentValues object
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, user.getUsername());
        values.put(UserTable.COL_PASSWORD, user.getPassword());

        // insert values into database
        db.insert(UserTable.TABLE, null, values);
    }

    // method to update a given user in the system, if needed
    public void updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, user.getUsername());
        values.put(UserTable.COL_PASSWORD, user.getPassword());

        db.update(UserTable.TABLE,
                values, UserTable.COL_USERNAME + " = " + user.getUsername(), null);
    }

    // method to delete user from the database, if needed
    public void deleteUser(String username) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserTable.TABLE,
                UserTable.COL_USERNAME + " = " + username, null);
    }
}

