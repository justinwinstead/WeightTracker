package com.jwinstead.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private WeightDatabase mWeightDb;
    private EditText mUsername;
    private EditText mPassword;
    private Button mLogin;
    private Button mCreate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mWeightDb = WeightDatabase.getInstance(getApplicationContext());
        mUsername = findViewById(R.id.usernameField);
        mPassword = findViewById(R.id.passwordField);
        mLogin = findViewById(R.id.loginButton);
        mCreate = findViewById(R.id.accountButton);

        // on click listener for login button
        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = mWeightDb.getUser(mUsername.getText().toString());

                if (user != null) {
                    // on successful login
                    if (user.getPassword().equals(mPassword.getText().toString())) {
                        Intent intent = new Intent();

                        // create shared preferences to store username
                        SharedPreferences prefs = getApplicationContext().getSharedPreferences(
                                "com.jwinstead.weighttracker", Context.MODE_PRIVATE);
                        prefs.edit().putString("name", user.getUsername()).commit();

                        // finish activity
                        setResult(RESULT_OK, intent);
                        finish();
                    }

                    // if the user enters an invalid password
                    else {
                        Toast.makeText(getApplicationContext(), R.string.invalid_password, Toast.LENGTH_SHORT).show();
                    }
                }

                // if the user doesn't exist
                else {
                    Toast.makeText(getApplicationContext(), R.string.user_not_found, Toast.LENGTH_SHORT).show();
                }
            }
        });

        // on click listener for the create account button
        mCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create user object and add username and password
                User user = new User();
                user.setUsername(mUsername.getText().toString());
                user.setPassword(mPassword.getText().toString());

                // ensure username is long enough
                if (user.getUsername().length() < 5) {
                    Toast.makeText(getApplicationContext(), R.string.username_too_short, Toast.LENGTH_SHORT).show();
                }

                // ensure password is long enough
                 else if (user.getPassword().length() < 5) {
                    Toast.makeText(getApplicationContext(), R.string.password_too_short, Toast.LENGTH_SHORT).show();
                }

                // if username and password are correct length
                else {
                    // ensure user is not already in system
                    if (mWeightDb.getUser(user.getUsername()) == null) {
                        mWeightDb.addUser(user);
                        mUsername.setText("");
                        mPassword.setText("");
                    }

                    // if username is already in use
                    else {
                        Toast.makeText(getApplicationContext(), R.string.username_taken, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}