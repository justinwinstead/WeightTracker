package com.jwinstead.weighttracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_USERNAME = "com.jwinstead.weighttracker.username";
    public static final String EXTRA_INPUT = "com.jwinstead.weighttracker.input";
    public static final String EXTRA_ID = "com.jwinstead.weighttracker.id";
    public static final String EXTRA_WEIGHT = "com.jwinstead.weighttracker.weight";

    private WeightDatabase mWeightDb;
    private RecyclerView mRecyclerView;
    private String mUsername;
    private long mCurWeight;
    private TextView mGoalText;
    private SharedPreferences mPrefs;
    private FloatingActionButton mFloatingActionButton;
    private Button mEditGoalButton;
    private Button mNotifyButton;
    private WeightAdapter mWeightAdapter;
    private Weight mSelectedWeight;
    private int mSelectedWeightPosition = RecyclerView.NO_POSITION;
    private ActionMode mActionMode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFloatingActionButton = findViewById(R.id.addWeightButton);
        mEditGoalButton = findViewById(R.id.goalEdit);
        mNotifyButton = findViewById(R.id.notifyButton);

        // prompt the user to log in if they are not logged in
        if (mUsername == null) {
            // create intent for login activity and start it
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        }

        mEditGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create intent for input activity
                Intent intent = new Intent(MainActivity.this, InputActivity.class);

                // retrieve username to send to input activity
                mPrefs = getApplicationContext().getSharedPreferences("com.jwinstead.weighttracker", Context.MODE_PRIVATE);
                mUsername = mPrefs.getString("name", "");

                // put extras for the intent and start the activity
                intent.putExtra(EXTRA_USERNAME, mUsername);
                intent.putExtra(EXTRA_INPUT, "goal");
                startActivity(intent);
            }
        });

        // on click listener for the notify button
        mNotifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // if the user has not given permission prompt them to do so
                if (ContextCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.SEND_SMS}, 1);
                }

                // display message to indicate the user has already given permission
                else {
                    Toast.makeText(MainActivity.this, "Permission already granted",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        // on click listener for the create button
        mFloatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create intent for input activity
                Intent intent = new Intent(MainActivity.this, InputActivity.class);

                // retrieve username to send to input activity
                mPrefs = getApplicationContext().getSharedPreferences("com.jwinstead.weighttracker", Context.MODE_PRIVATE);
                mUsername = mPrefs.getString("name", "");

                // put extras for the intent and start the activity
                intent.putExtra(EXTRA_USERNAME, mUsername);
                intent.putExtra(EXTRA_INPUT, "create");
                startActivity(intent);

                /*
                an attempt to set up the SMS service

                intent = getIntent();
                mCurWeight = intent.getLongExtra(EXTRA_WEIGHT, 0);
                if (mCurWeight <= mWeightDb.getGoal(mUsername).getGoal()) {
                    TelephonyManager mTelephonyManager = (TelephonyManager)
                            getSystemService(TELEPHONY_SERVICE);
                    if (ContextCompat.checkSelfPermission(getApplicationContext(),
                            Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        String userNumber = mTelephonyManager.getLine1Number();
                        SmsManager.getDefault().sendTextMessage(userNumber, null,
                                "Congratulations! You have reached your WeightTracker goal!", null, null);
                    }
                }
                */
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        updateAdapter(); // put in on start to update the db, adapter, and goal text
    }

    // function to initialize db, adapter and goal text when they are changed
    private void updateAdapter() {
        mWeightDb = WeightDatabase.getInstance(getApplicationContext());
        mRecyclerView = findViewById(R.id.weightRecyclerView);

        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        mPrefs = getApplicationContext().getSharedPreferences("com.jwinstead.weighttracker", Context.MODE_PRIVATE);
        mUsername = mPrefs.getString("name", "");
        mWeightAdapter = new WeightAdapter(loadWeights(mUsername));
        mRecyclerView.setAdapter(mWeightAdapter);

        mGoalText = findViewById(R.id.goalUser);
        Goal userGoal = mWeightDb.getGoal(mUsername);
        if (userGoal != null) {
            mGoalText.setText(Long.toString(userGoal.getGoal()) + " pounds");
        }
    }

    // function to load weight list
    private List<Weight> loadWeights(String username) {
        return mWeightDb.getWeights(username);
    }

    // class for items in the weight adapter
    private class WeightHolder extends RecyclerView.ViewHolder
    implements View.OnLongClickListener {
        private Weight mWeight;
        private TextView mWeightText;
        private TextView mDateText;

        // default constructor
        public WeightHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            mWeightText = itemView.findViewById(R.id.weightText);
            mDateText = itemView.findViewById(R.id.dateText);
            itemView.setOnLongClickListener(this);
        }

        // binds the values in mWeight to the object
        public void bind(Weight weight, int position) {
            mWeight = weight;
            mWeightText.setText(Long.toString(weight.getWeight()));
            SimpleDateFormat mDF = new SimpleDateFormat("MM-dd-yyyy");
            Date mDate = new Date(weight.getDate());
            mDateText.setText("" + mDF.format(mDate));


        }

        // on long click to edit and delete weights
        @Override
        public boolean onLongClick(View view) {
            if (mActionMode != null) {
                return false;
            }

            // get the selected weight and the position of that weight
            mSelectedWeight = mWeight;
            mSelectedWeightPosition = getAbsoluteAdapterPosition();

            // re-bind the selected item
            mWeightAdapter.notifyItemChanged(mSelectedWeightPosition);

            // show the CAB
            mActionMode = MainActivity.this.startActionMode(mActionModeCallback);

            return true;
        }


        private ActionMode.Callback mActionModeCallback = new ActionMode.Callback() {

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                // provide context menu for CAB
                MenuInflater inflater = mode.getMenuInflater();
                inflater.inflate(R.menu.context_menu, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                // process action item selection
                switch (item.getItemId()) {
                    // if the user chooses to delete
                    case R.id.delete:
                        // delete from the database and remove from the RecyclerView
                        mWeightDb.deleteWeight(mSelectedWeight.getId());
                        mWeightAdapter.removeWeight(mSelectedWeight);

                        // close the CAB
                        mode.finish();
                        return true;

                    // if the user chooses to edit
                    case R.id.edit:
                        // create intent for input activity
                        Intent intent = new Intent(MainActivity.this, InputActivity.class);

                        // retrieve username to send to input activity
                        mPrefs = getApplicationContext().getSharedPreferences("com.jwinstead.weighttracker", Context.MODE_PRIVATE);
                        mUsername = mPrefs.getString("name", "");

                        // put extras for the intent and start the activity
                        intent.putExtra(EXTRA_USERNAME, mUsername);
                        intent.putExtra(EXTRA_INPUT, "edit");
                        intent.putExtra(EXTRA_ID, mWeight.getId());
                        startActivity(intent);

                        // close the CAB
                        mode.finish();
                        return true;
                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                mActionMode = null;

                // CAB closing, need to deselect item if not deleted
                mWeightAdapter.notifyItemChanged(mSelectedWeightPosition);
                mSelectedWeightPosition = RecyclerView.NO_POSITION;
            }
        };


    }

    // class for the recycler view adapter
    private class WeightAdapter extends RecyclerView.Adapter<WeightHolder> {
        private List<Weight> mWeightList;

        // constructor that initializes with weightlist
        public WeightAdapter(List<Weight> weights) {
            mWeightList = weights;
        }

        // create holder for each item
        @Override
        public WeightHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new WeightHolder(layoutInflater, parent);
        }

        // bind holder to position
        @Override
        public void onBindViewHolder(WeightHolder holder, int position) {
            holder.bind(mWeightList.get(position),  position);
        }

        @Override
        public int getItemCount() {
            return mWeightList.size();
        }

        // function to remove a weight from adapter
        public void removeWeight(Weight weight) {
            // find weight in the list
            int index = mWeightList.indexOf(weight);
            if (index >= 0) {
                // remove the weight
                mWeightList.remove(index);

                // notify adapter of weight removal
                notifyItemRemoved(index);
            }
        }
    }

}