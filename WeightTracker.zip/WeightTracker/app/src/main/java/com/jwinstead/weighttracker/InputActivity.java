package com.jwinstead.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class InputActivity extends AppCompatActivity {

    public static final String EXTRA_USERNAME = "com.jwinstead.weighttracker.username";
    public static final String EXTRA_INPUT = "com.jwinstead.weighttracker.input";
    public static final String EXTRA_ID = "com.jwinstead.weighttracker.id";
    public static final String EXTRA_WEIGHT = "com.jwinstead.weighttracker.weight";

    private WeightDatabase mWeightDb;
    private String mUsername;
    private String mInputOption;
    private long mWeightId;
    private EditText mDateText;
    private EditText mWeightText;
    private String mDateString;
    private Button mSubmit;
    private Date mDate;
    private final SimpleDateFormat mDF = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
    private DatePickerDialog mDatePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);
        mInputOption = intent.getStringExtra(EXTRA_INPUT);
        mWeightDb = WeightDatabase.getInstance(getApplicationContext());
        mWeightText = findViewById(R.id.weightField);
        mSubmit = findViewById(R.id.submitButton);
        mDateText = findViewById(R.id.dateField);

        // set on click listener to show a date picker dialog
        mDateText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar mCalendar = Calendar.getInstance();
                int mYear = mCalendar.get(Calendar.YEAR);
                int mMonth = mCalendar.get(Calendar.MONTH);
                int mDay = mCalendar.get(Calendar.DAY_OF_MONTH);
                mDatePickerDialog = new DatePickerDialog(InputActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            // when the user submits their date
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                // format and parse entered date and put it in field
                                mDateString = (month + 1) + "-" + day + "-" + year;
                                mDateText.setText(mDateString);

                                try {
                                    mDate = mDF.parse(mDateString);
                                }
                                catch (ParseException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, mYear, mMonth, mDay);
                mDatePickerDialog.show();
            }
        });


        // set different on clicks for different buttons pressed to enter this activity
        switch(mInputOption) {
            // if the FAB was pressed
            case "create":
                // on click for submit button
                mSubmit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Weight weight = new Weight();

                        // try to assign values to weight object
                        try {
                            weight.setWeight(Integer.parseInt(mWeightText.getText().toString()));
                            weight.setDate(mDate.getTime());
                            weight.setUser(mUsername);
                        }
                        catch (NullPointerException e) {
                            Toast.makeText(InputActivity.this, "Invalid Input",
                                    Toast.LENGTH_SHORT).show();
                        }

                        // add weight to db
                        mWeightDb.addWeight(weight);

                        Intent intent = new Intent();
                        intent.putExtra(EXTRA_WEIGHT, weight.getWeight());
                        setResult(RESULT_OK, intent);
                        finish();

                    }
                });
                break;

            // if the edit button was pressed
            case "edit":
                // retrieve weight to be edited
                mWeightId = intent.getLongExtra(EXTRA_ID, 0);
                Weight weight = mWeightDb.getWeight(mWeightId);

                // set fields to current values
                mWeightText.setText(Long.toString(weight.getWeight()));
                mDate = new Date(weight.getDate());
                mDateText.setText(mDF.format(mDate));

                // sets on click listener for submit button
                mSubmit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Weight weight = mWeightDb.getWeight(mWeightId);

                        // try to update weight values
                        try {
                            weight.setWeight(Integer.parseInt(mWeightText.getText().toString()));
                            weight.setDate(mDate.getTime());
                        }
                        catch (NullPointerException e) {
                            Toast.makeText(InputActivity.this, "Invalid Input",
                                    Toast.LENGTH_SHORT).show();
                        }

                        // update weight in database
                        mWeightDb.updateWeight(weight);

                        Intent intent = new Intent();
                        intent.putExtra(EXTRA_WEIGHT, weight.getWeight());
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                });
                break;

            // if the goal edit button was pressed
            case "goal":
                // get rid of date fields
                mDateText.setVisibility(View.GONE);
                findViewById(R.id.dateLabel).setVisibility(View.GONE);

                // if the user does not have a goal
                if (mWeightDb.getGoal(mUsername) == null) {
                    // set on click listener for submit button
                    mSubmit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Goal goal = new Goal();

                            // try to assign values to goal
                            try {
                                goal.setGoal(Integer.parseInt(mWeightText.getText().toString()));
                                goal.setUser(mUsername);
                            }
                            catch (NullPointerException e) {
                                Toast.makeText(InputActivity.this, "Invalid Input",
                                        Toast.LENGTH_SHORT).show();
                            }

                            // add goal to database
                            mWeightDb.addGoal(goal);

                            Intent intent = new Intent();
                            setResult(RESULT_OK, intent);
                            finish();
                        }
                    });
                }

                // if the user has a goal already
                else {
                    // set on click listener for submit button
                    mSubmit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Goal goal = mWeightDb.getGoal(mUsername);

                            // try to update goal values
                            try {
                                goal.setGoal(Integer.parseInt(mWeightText.getText().toString()));
                            }
                            catch (NullPointerException e) {
                                Toast.makeText(InputActivity.this, "Invalid Input",
                                        Toast.LENGTH_SHORT).show();
                            }

                            // update goal in database
                            mWeightDb.updateGoal(goal);

                            Intent intent = new Intent();
                            setResult(RESULT_OK, intent);
                            finish();
                        }
                    });
                }
                break;
        }
    }
}